
/**
 * Pertemuan 2 [Tugas]
 *
 * @author 2473021-Febrianus Leona Putra
 * @version 04 Maret 2025
 */
public class BuahDirector {

    public static void main(String[] args) {
        Buah apel = new Buah("Apel", "Hijau", "Manis", 5);
        System.out.println(apel);

        Buah jeruk = new Buah("Jeruk", "Orange", "Manis-Asam", 10);
        System.out.println(jeruk);
    }
}
