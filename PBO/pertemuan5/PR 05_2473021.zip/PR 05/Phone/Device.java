
/**
 * Pertemuan 5 [PR]
 *
 * @author 2473021-Febrianus Leona Putra
 * @version 27 Maret 2025
 */
public abstract class Device implements VoIP {

    public void powerOn() {
        System.out.println("Device is powered on.");
    }

    public void powerOff() {
        System.out.println("Device is powered off.");
    }
}
