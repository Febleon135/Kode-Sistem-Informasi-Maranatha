
/**
 * Pertemuan 5 [Praktikum]
 *
 * @author 2473021-Febrianus Leona Putra
 * @version 21 Maret 2025
 */
public class Harimau extends Kucing {

    public Harimau() {
        super("Harimau");
    }

    @Override
    public String bersuara() {
        return "hauunnnngggg...";
    }
}
