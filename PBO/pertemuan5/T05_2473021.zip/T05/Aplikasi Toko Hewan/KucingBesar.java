
/**
 * Pertemuan 5 [Praktikum]
 *
 * @author 2473021-Febrianus Leona Putra
 * @version 21 Maret 2025
 */
public class KucingBesar extends Kucing {

    public KucingBesar() {
        super("Kucing Besar");
    }

    @Override
    public String bersuara() {
        return "meoooonnngggg...";
    }
}
