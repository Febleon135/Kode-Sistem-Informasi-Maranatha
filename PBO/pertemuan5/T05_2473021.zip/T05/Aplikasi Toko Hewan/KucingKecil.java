
/**
 * Pertemuan 5 [Praktikum]
 *
 * @author 2473021-Febrianus Leona Putra
 * @version 21 Maret 2025
 */
public class KucingKecil extends Kucing {

    public KucingKecil() {
        super("Kucing Kecil");
    }

    @Override
    public String bersuara() {
        return "miau...miau...miau...";
    }
}
