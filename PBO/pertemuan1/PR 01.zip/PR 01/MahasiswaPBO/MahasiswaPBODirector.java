
/**
 * Pertemuan 1 [PR]
 *
 * @author 2473021-Febrianus Leona Putra
 * @version 25 Februari 2025
 */
public class MahasiswaPBODirector {

    public static void main(String[] args) {
        MahasiswaPBO newMahasiswaPBO = new MahasiswaPBO();
        newMahasiswaPBO.setNrp("0733077");
        newMahasiswaPBO.setNama("Sendy Ferdian Sujadi");
        newMahasiswaPBO.setUts(77f);
        newMahasiswaPBO.setUas(77f);
        newMahasiswaPBO.setKat(65f);

        System.out.println(newMahasiswaPBO.toString());
    }
}
