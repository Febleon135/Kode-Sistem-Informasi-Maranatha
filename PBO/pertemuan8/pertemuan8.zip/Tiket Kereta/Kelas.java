
public class Kelas {

    String jenis;
    double harga;

    public Kelas(String jenis, double harga) {
        this.jenis = jenis;
        this.harga = harga;
    }
}
