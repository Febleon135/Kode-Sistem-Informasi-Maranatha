
public interface Peminjaman {

    void peminjaman();

    void pengembalian();
}
