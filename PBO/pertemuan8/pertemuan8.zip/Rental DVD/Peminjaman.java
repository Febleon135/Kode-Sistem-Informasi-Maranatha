
public interface Peminjaman {

    public void peminjaman();

    public void pengembalian();
}
